CREATE TABLE IF NOT EXISTS Asignatura(
  id SERIAL,
        Nombre VARCHAR (100) NOT NULL,
        Ciclo VARCHAR(50) NOT NULL,
        Creditos INT,
      PRIMARY KEY (id)
      );