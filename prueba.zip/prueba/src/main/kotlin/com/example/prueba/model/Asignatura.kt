package com.example.prueba.model

import javax.persistence.*

@Entity
@Table(name="Asignatura")
class Asignatura{
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(updatable=false)

        var id: Long? = null
        var nombre: String?= null
        var ciclo: String? = null
        var creditos: Long? = null

}