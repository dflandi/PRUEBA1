package com.example.prueba

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class PruebaApplication

fun main(args: Array<String>) {
	runApplication<PruebaApplication>(*args)
}
