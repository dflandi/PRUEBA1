package com.example.prueba.controller

import com.example.prueba.model.Asignatura
import com.example.prueba.service.AsignaturaService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*


@RestController
@RequestMapping("/Asignaturas")
@CrossOrigin(methods = [RequestMethod.GET, RequestMethod.POST, RequestMethod.PATCH])
class AsignaturaController {
    @Autowired
    lateinit var asignaturaService: AsignaturaService

    @GetMapping
    fun list ():List <Asignatura>{
        return asignaturaService.list()
    }
    @PostMapping
    fun save(@RequestBody asignatura: Asignatura):Asignatura{
        return asignaturaService.save(asignatura)
    }
    @PatchMapping
    fun updateName (@RequestBody asignatura: Asignatura): Asignatura {
        return asignaturaService.updateName(asignatura)
    }
}