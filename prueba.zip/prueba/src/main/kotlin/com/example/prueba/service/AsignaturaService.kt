package com.example.prueba.service

import com.example.prueba.model.Asignatura
import com.example.prueba.repository.AsignaturaRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import org.springframework.web.bind.annotation.RequestBody

@Service
class AsignaturaService {
    @Autowired
    lateinit var asignaturaRepository: AsignaturaRepository
    fun list() : List<Asignatura> {
        return asignaturaRepository.findAll()
    }
    fun save ( asignatura:Asignatura): Asignatura {
        return asignaturaRepository.save(asignatura)
    }

    fun updateName(Asignatura: Asignatura):Asignatura{

        val response = asignaturaRepository.findById(Asignatura.id)
            ?: throw Exception()

        response.apply{
             id = Asignatura.id
            nombre = Asignatura.nombre
            ciclo = Asignatura.ciclo
            creditos = Asignatura.creditos


        }
        return asignaturaRepository.save(response)

    }
    }
