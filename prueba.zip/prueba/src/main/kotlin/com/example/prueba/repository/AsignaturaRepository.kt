package com.example.prueba.repository

import com.example.prueba.model.Asignatura
import org.springframework.data.jpa.repository.JpaRepository

interface AsignaturaRepository: JpaRepository<Asignatura, Long> {
    fun findById(id:Long?):Asignatura?
}